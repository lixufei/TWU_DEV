package com.twu.biblioteca;

import org.hamcrest.Matcher;
import org.omg.Messaging.SYNC_WITH_TRANSPORT;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.Scanner;

/**
 * Created by Lily on 2015/6/2.
 */
public class Book {

    public String showMsg()throws IOException{
        System.out.println("Welcome to The Bangalore Public Library");
//        System.out.println("There exist list of books:book_name1,book_name2,book_name3");
        System.out.println("And do what you want according to the following choices or input any name of the book to see details:");
        System.out.println("Main Menu,Checkout Book,Return Book");
        System.out.print("your choice:");
//        Scanner scan = new Scanner(System.in);
//        System.out.println("please input:");
//        System.out.println(scan.next());
//        BufferedReader buffer = new BufferedReader(new InputStreamReader(System.in));
//        System.out.println(buffer.readLine());
//        System.in.read();
        return "Welcome to The Bangalore Public Library";
    }

    public String listBooks(String lstBooks){
        if (lstBooks.equals("List Books")){
            String bookNames = "book_name1,book_name2,book_name3";
            System.out.println(bookNames);
            return bookNames;
        }
        return null;
    }
            public String bookDetails(String bookName) {
                if (bookName.equals("book_name1")){
                    System.out.println("Author:author1");
                    System.out.println("Year Published:year1");
                }else if (bookName.equals("book_name2")){
                    System.out.println("Author:author2");
                    System.out.println("Year Published:year2");
                }else if (bookName.equals("book_name3")){
                    System.out.println("Author:author3");
                    System.out.println("Year Published:year3");
                }
                return "details";
    }

    public boolean menuOption(String option) {
        String lstBooks = "List Books";
        if (!option.equals(lstBooks)){
            System.out.println("Select a valid option!");
            return false;
        }
        System.out.println("book_name1,book_name2,book_name3");
        return true;
    }

    public String toQuit(String quit){
        return "thanks for your visiting";
    }

    public boolean checkOutBook(String bookName) {
        String bookNames[] = {"book_name1","book_name2","book_name3"};
        for (int i = 0;i < bookNames.length;i++){
            if (bookName.equals(bookNames[i])){
                System.out.println("Thank you! Enjoy the book");
                return true;
            }
        }
        System.out.println("That book is not available.");
        return false;
    }

    public boolean returnBook(String bookName) {
        String bookNames[] = {"book_name1","book_name2","book_name3"};
        for (int i = 0;i < bookNames.length;i++){
            if (bookName.equals(bookNames[i])){
                System.out.println("Thank you for returning the book.");
                return true;
            }
        }
        System.out.println("That is not a valid book to return.");
        return false;
    }
}

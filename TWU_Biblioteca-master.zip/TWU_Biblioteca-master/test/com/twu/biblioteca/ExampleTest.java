package com.twu.biblioteca;


import org.junit.Test;

import javax.lang.model.element.NestingKind;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

import static org.hamcrest.CoreMatchers.equalTo;
import static org.hamcrest.CoreMatchers.not;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertThat;

public class ExampleTest {

    @Test
    public void test() {
        assertEquals(1, 1);
    }

    @Test
    public void show_welcome_msg()throws IOException{
        String msg = "Welcome to The Bangalore Public Library";
        assertThat(msg, equalTo(new Book().showMsg()));
    }

    @Test
    public void list_books(){
        assertThat(null,not(equalTo(new Book().listBooks("List Books"))));
    }
    @Test
    public void show_book_details(){
        String bookName = "book_name1";
        assertThat(null, not(equalTo(new Book().bookDetails(bookName))));
    }

    @Test
    public void is_valid_menu_option(){
        String option = "List Books";
        assertThat(null, not(equalTo(new Book().menuOption(option))));
    }

    @Test
    public void check_quit(){
        String quit = "quit";
        assertThat(null, not(equalTo(new Book().toQuit(quit))));
    }

    @Test
    public void check_out_book(){
        String bookName = "book_name1";
        assertThat(null, not(equalTo(new Book().checkOutBook(bookName))));
    }

    @Test
    public void return_book(){
        String bookName = "book_nme1";
        assertThat(null,not(equalTo(new Book().returnBook(bookName))));
    }
}

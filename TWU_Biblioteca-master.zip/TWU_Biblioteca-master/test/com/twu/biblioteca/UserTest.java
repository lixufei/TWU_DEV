package com.twu.biblioteca;

import org.junit.Test;

import static org.hamcrest.CoreMatchers.equalTo;
import static org.hamcrest.CoreMatchers.not;
import static org.junit.Assert.assertThat;

/**
 * Created by Lily on 2015/6/7.
 */
public class UserTest {
    @Test
    public void check_user(){
        assertThat(null, not(equalTo(new Source().findByNum("000"))));
    }
}

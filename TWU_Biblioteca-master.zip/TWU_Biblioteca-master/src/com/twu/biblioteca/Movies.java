package com.twu.biblioteca;

/**
 * Created by Lily on 2015/6/7.
 */
public class Movies {

    private String movieName;
    private String movieYear;
    private String director;
    private String rating;

    public String getMovieName() {
        return movieName;
    }

    public void setMovieName(String movieName) {
        this.movieName = movieName;
    }

    public String getMovieYear() {
        return movieYear;
    }

    public void setDerector(String movieYear) {
        this.movieYear = movieYear;
    }

    public String getDirector() {
        return director;
    }

    public void setMovieYear(String director) {
        this.director = director;
    }

    public String getRating() {
        return rating;
    }

    public void setRating(String rating) {
        this.rating = rating;
    }
}

package com.twu.biblioteca;

import java.util.Scanner;

public class BibliotecaApp {

    static Login login = new Login();
    static Source source = new Source();
    static Admin admin = new Admin();
    public static void main(String[] args) {
        choose_login();
    }

    public static void choose_login(){
        login.showWelcome();
        Scanner aOru = new Scanner(System.in);
        int choice = aOru.nextInt();
        if (choice == 1){
            System.out.println("your admin number:");
            Scanner sc = new Scanner(System.in);
            String adminNum = sc.next();
            System.out.println("your admin password:");
            Scanner s = new Scanner(System.in);
            String adminPwd = s.next();
                if (login.adminLogin(adminNum, adminPwd) == true) {
                    adminTable();
                } else {
                    System.out.println("your number or password is not correct!");
                }
        }else if (choice == 2){
            System.out.println("your user number:");
            Scanner sc = new Scanner(System.in);
            String userNum = sc.next();
            System.out.println("your user password:");
            Scanner s = new Scanner(System.in);
            String userPwd = sc.next();
            if ( login.userLogin(userNum,userPwd) == true){
                userTable();
            }else {
                System.out.println("your number or password is not correct!");
            }
        }
    }

    public static void adminTable(){
        admin.show_admin_table();
        for (int i = 0;i < 3;i++){
            Scanner aOru = new Scanner(System.in);
        int choice = aOru.nextInt();
            if(choice != 2) {
                admin.adminOperations(choice);
            }else {
                admin.adminOperations(choice);
                break;
            }
        }
    }

    public static void userTable(){
        source.userFrame();
            for (int i = 0; i < 15; i++) {
                Scanner we = new Scanner(System.in);
                int choices = we.nextInt();
                if (choices != 6) {
                    source.operations(choices);
                }else {
                    source.operations(choices);
                    break;
                }
            }
    }
}

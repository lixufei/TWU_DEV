package com.twu.biblioteca;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

/**
 * Created by Lily on 2015/6/8.
 */
public class Admin {
    public static void show_admin_table(){
        System.out.println("------------------");
        System.out.println("1.Books checked out");
        System.out.println("2.Quit");
        System.out.println("------------------");
    }

    public static void adminOperations(int num){
        switch (num){
            case 1:
                for (int i = 0;i < books_checked_out().size();i++){
                    System.out.println("book name:" + books_checked_out().get(i).getBookName());
                    System.out.println("user name:" + books_checked_out().get(i).getUser().getUserNum());
                }
                break;
            case 2:
                System.out.println("Thanks for your visiting!");
                break;
            default:
                System.out.println("your input is not correct!");
                break;
        }
    }
    public static List<Book> books_checked_out(){
        List<Book> checkedOutBooks = new ArrayList<Book>();
        Source source = new Source();
        int len = source.lstBooks().size();
        for (int i = 0;i < len;i++){
            if (source.lstBooks().get(i).getState() == 1){
                checkedOutBooks.add(source.lstBooks().get(i));
            }
        }
        return checkedOutBooks;
    }
}

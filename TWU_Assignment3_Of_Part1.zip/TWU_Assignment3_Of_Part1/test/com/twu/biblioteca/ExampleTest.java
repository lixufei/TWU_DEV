package com.twu.biblioteca;


import org.junit.Test;


import static org.hamcrest.CoreMatchers.equalTo;
import static org.hamcrest.CoreMatchers.not;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertThat;

public class ExampleTest {

    @Test
    public void test() {
        assertEquals(1, 1);
    }

    @Test
    public void one_star(){
        assertThat(null, not(equalTo(new Triangle().printOneStar())));
    }

    @Test
    public void horizontal_line(){
        int num = 3;
        assertThat(null, not(equalTo(new Triangle().printHorizantalLine(num))));
    }

    @Test
    public void vertical_line(){
        int num = 4;
        assertThat(null, not(equalTo(new Triangle().printVerticlaLine(num))));
    }

    @Test
    public void right_triangle(){
        int num = 3;
        assertThat(null, not(equalTo(new Triangle().printRightTriangle(num))));
    }

    @Test
    public void centered_triangle(){
        int num = 5;
        assertThat(null, not(equalTo(new Triangle().printCenteredTriangle(num))));
    }

    @Test
    public void centered_diamond(){
        int num = 3;
        assertThat(null, not(equalTo(new Triangle().printCenteredDiamond(num))));
    }

    @Test
    public void diamond_with_name(){
        int num = 3;
        assertThat(null, not(equalTo(new Triangle().printDiamondWithName(num))));
    }

    @Test
    public void test_FizzBuzz(){
        assertThat(null, not(equalTo(new Triangle().FizzBuzz())));
    }

    @Test
    public void test_generate(){
        int num = 40;
        assertThat(null, not(equalTo(new Triangle().generate(num))));
    }
}

package com.twu.biblioteca;

/**
 * Created by Lily on 2015/6/2.
 */
public class Triangle {


    public String printOneStar() {
        System.out.println("*");
        return "printOneStar";
    }

    public String printHorizantalLine(int num) {
        for(int i = 1;i <= num;i++){
            System.out.print("*");
        }
        return "printHorizantalLine";
    }

    public String printVerticlaLine(int num) {
        for(int i = 1;i <= num;i++){
            System.out.println("*");
        }
        return "printVerticlaLine";
    }

    public String printRightTriangle(int num) {
        for(int i = 1;i <= num;i++){
            for(int j = 1;j <= i;j++){
                System.out.print("*");
            }
            System.out.println();
        }
        return "printRightTriangle";
    }

    public String printCenteredTriangle(int num) {
        for (int i = 1;i <= num;i++){
            for(int m = 1;m <= 2*num-2*i;m++){
                System.out.print(" ");
            }
            for(int j =  1;j <=  2*i-1;j++){
                System.out.print("*");
            }
            System.out.println();
        }
        return "printCenteredTriangle";
    }

    public String printCenteredDiamond(int num) {
        int i = 0;
        for (i = 1;i <= 2*num-1;i++) {
            if (i < num) {
                for (int m = 1; m <= 2 * num - 2 * i; m++) {
                    System.out.print(" ");
                }
                for (int j = 1; j <= 2 * i - 1; j++) {
                    System.out.print("*");
                }
                System.out.println();
            }else if (i == num){
                for (int n = 1;n <= 2*num-1;n++){
                    System.out.print("*");
                }
                System.out.println();
            }else if (i > num && i <= 2*num -1){
                for (int m = 1; m <= 2 * i - 2 * num; m++) {
                    System.out.print(" ");
                }
                for (int j = 1; j <= 4 * num - 2 * i - 1; j++) {
                    System.out.print("*");
                }
                System.out.println();
            }
        }
        return "printCenteredDiamond";
    }

    public String printDiamondWithName(int num) {
        int i = 0;
        for (i = 1;i <= 2*num-1;i++) {
            if (i < num) {
                for (int m = 1; m <= 2 * num - 2 * i; m++) {
                    System.out.print(" ");
                }
                for (int j = 1; j <= 2 * i - 1; j++) {
                    System.out.print("*");
                }
                System.out.println();
            }else if (i == num){
                System.out.println("Bill");
            }else if (i > num && i <= 2*num -1){
                for (int m = 1; m <= 2 * i - 2 * num; m++) {
                    System.out.print(" ");
                }
                for (int j = 1; j <= 4 * num - 2 * i - 1; j++) {
                    System.out.print("*");
                }
                System.out.println();
            }
        }
        return "printDiamondWithName";
    }

    public String FizzBuzz() {
        for (int i = 1;i <= 100;i++){
            if (i % 15 ==0){
                System.out.println("FizzBuzz");
            }else if (i % 5 ==0){
                System.out.println("Buzz");
            }else if (i % 3 == 0){
                System.out.println("Fizz");
            }else {
                System.out.println(i);
            }
        }
        return "FizzBuzz";
    }

    public String generate(int num) {
        for (int i=2;i <=num;i++) {
            if (i == num) {
                System.out.print(i + ",");
                return "end";
            }
            if (num > i && (num % i == 0)) {
                System.out.print(i + ",");
                generate(num / i);
                break;
            }
        }
        return "ok";
        }
}
